# tuichat_android_java
Create chat app with Android-Java + Firebase
